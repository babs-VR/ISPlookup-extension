const ipInput    = document.getElementById('ip-input');
const lookupBtn  = document.getElementById('lookup-btn');
const errorBanner = document.getElementById('error-banner');
const loading    = document.getElementById('loading');
const results    = document.getElementById('results');
const voipTip    = document.getElementById('voip-tip');

function isValidIP(val) {
  // IPv4
  const v4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  // IPv6 (basic check)
  const v6 = /^[0-9a-fA-F:]{2,39}$/;
  return v4.test(val) || v6.test(val);
}

function setLoading(on) {
  loading.classList.toggle('visible', on);
  lookupBtn.disabled = on;
  lookupBtn.textContent = on ? '...' : 'Look Up';
}

function showError(msg) {
  errorBanner.textContent = msg;
  errorBanner.classList.add('visible');
  results.classList.remove('visible');
  voipTip.classList.remove('visible');
}

function hideError() {
  errorBanner.classList.remove('visible');
}

function getConnectionType(data) {
  const org = (data.org || '').toLowerCase();
  const isp = (data.isp || '').toLowerCase();
  const combined = org + ' ' + isp;

  if (/hosting|cloud|aws|azure|google|digitalocean|linode|vultr|ovh|datacenter|data center|coloc/.test(combined)) {
    return { label: 'Hosting / Cloud', type: 'hosting' };
  }
  if (/comcast|xfinity|spectrum|cox|att|verizon|frontier|centurylink|lumen|charter|cable|dsl|fiber|residential/.test(combined)) {
    return { label: 'Residential ISP', type: 'residential' };
  }
  if (/business|enterprise|corp|telecom|communications|wireless|mobile|cellular/.test(combined)) {
    return { label: 'Business / Telecom', type: 'business' };
  }
  return { label: 'Unknown', type: 'unknown' };
}

function getVoipTip(connType, data) {
  const isp = (data.isp || '').toLowerCase();

  if (connType === 'residential') {
    return `<strong>⚠️ Residential ISP detected.</strong> Customer may be behind CGNAT or a double NAT. Common causes of one-way audio, dropped calls, or registration failures. Ask if they have SIP ALG enabled on their router.`;
  }
  if (connType === 'hosting') {
    return `<strong>ℹ️ Hosting / Data Center IP.</strong> This is likely a PBX, SBC, or hosted VoIP platform. Not a typical end-user device — check if this is their provider's infrastructure.`;
  }
  if (connType === 'business') {
    return `<strong>✅ Business / Telecom IP.</strong> Typically has better routing and static IPs. If call quality issues exist, focus on QoS, jitter, and firewall rules rather than NAT.`;
  }
  return null;
}

async function doLookup() {
  const ip = ipInput.value.trim();

  if (!ip) {
    ipInput.classList.add('error');
    showError('Please enter an IP address.');
    return;
  }

  if (!isValidIP(ip)) {
    ipInput.classList.add('error');
    showError('That doesn\'t look like a valid IP address.');
    return;
  }

  ipInput.classList.remove('error');
  hideError();
  setLoading(true);
  results.classList.remove('visible');
  voipTip.classList.remove('visible');

  try {
    const res = await fetch(
      `http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,message,country,regionName,city,isp,org,as,query,timezone,mobile,proxy,hosting`
    );
    const data = await res.json();

    if (data.status === 'fail') {
      showError(`Lookup failed: ${data.message || 'Unknown error'}`);
      setLoading(false);
      return;
    }

    // Populate fields
    document.getElementById('res-ip').textContent = data.query;

    document.getElementById('res-isp').textContent = data.isp || '—';
    document.getElementById('res-asn').textContent = data.as || '—';

    const location = [data.city, data.regionName, data.country].filter(Boolean).join(', ');
    document.getElementById('res-location').textContent = location || '—';

    document.getElementById('res-tz').textContent = data.timezone || '—';

    // Connection type
    const conn = getConnectionType(data);
    const badge = document.getElementById('res-conn-badge');
    badge.textContent = conn.label;
    badge.className = `conn-badge ${conn.type}`;

    // Type row — add proxy/mobile flags
    const flags = [];
    if (data.proxy) flags.push('Proxy / VPN');
    if (data.mobile) flags.push('Mobile');
    if (data.hosting) flags.push('Datacenter');
    const typeEl = document.getElementById('res-type');
    typeEl.textContent = flags.length ? flags.join(', ') : conn.label;

    results.classList.add('visible');

    // VoIP tip
    const tip = getVoipTip(conn.type, data);
    if (tip) {
      voipTip.innerHTML = tip;
      voipTip.classList.add('visible');
    }

  } catch (e) {
    showError('Network error — check your connection and try again.');
  }

  setLoading(false);
}

// Enter key support
ipInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') doLookup();
});

ipInput.addEventListener('input', () => {
  ipInput.classList.remove('error');
  hideError();
});

lookupBtn.addEventListener('click', doLookup);

// Per-row copy buttons
document.querySelectorAll('.copy-row-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const fieldId = btn.getAttribute('data-field');
    const val = document.getElementById(fieldId)?.textContent;
    if (!val || val === '—') return;
    navigator.clipboard.writeText(val).then(() => {
      btn.textContent = 'Copied!';
      btn.classList.add('copied');
      setTimeout(() => {
        btn.textContent = 'Copy';
        btn.classList.remove('copied');
      }, 1500);
    });
  });
});
